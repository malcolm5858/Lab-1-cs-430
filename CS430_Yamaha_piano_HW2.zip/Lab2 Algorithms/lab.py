def findMaxSubarray(array):
    currentMax = 0
    maxStart = 0
    maxEnd = 0

    for i in range(len(array)):
        sum = 0
        for j in range(i, len(array)):
            sum += array[j]
            if sum > currentMax:
                currentMax = sum
                maxStart = i
                maxEnd = j
    
    return (maxStart, maxEnd, currentMax)

print(findMaxSubarray([10,3,4,-2,4,5,6,9,-3,-4,-5,5])) # change this array to test different arrays